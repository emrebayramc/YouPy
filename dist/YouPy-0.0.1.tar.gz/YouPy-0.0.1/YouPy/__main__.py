from YouPy import YouTubeItem

youtube_item = YouTubeItem('https://www.youtube.com/embed/B48hwisZvEI', request_headers={
    'User-Agent':
        'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.116 Safari/537.36',
    'x-youtube-client-name':
        1,
    'x-youtube-identity-token':
        'QUFFLUhqa09CSTBkUW9ucG8zVGlCS1BoNmt5RHllUWtHZ3w=',
    'cookie':
        'HSID=AdwhItWf5tUHAA6Xz; SSID=AeChf5agRV7dKvUXD; APISID=wZ4qrQ1aoHaHc1Ry/AFDxLFZSX1IPRrkXl; SAPISID=GsJFRctC-VlXjmN_/AEDOrgoUUWp8o_23M; __Secure-HSID=AdwhItWf5tUHAA6Xz; __Secure-SSID=AeChf5agRV7dKvUXD; __Secure-APISID=wZ4qrQ1aoHaHc1Ry/AFDxLFZSX1IPRrkXl; __Secure-3PAPISID=GsJFRctC-VlXjmN_/AEDOrgoUUWp8o_23M; VISITOR_INFO1_LIVE=3oPd7rX9Gr4; LOGIN_INFO=AFmmF2swRQIhAKhjBEt5qMMWuZFU91u0G3mtI8yFyrfKbPd0lWTo37OTAiBdgTn98ennbEx07rXmCy7--tuCTFvaGQy1ozZdGkg0JQ:QUQ3MjNmenRFNVlRZEpwZVpjaXZDY1FDY09tVnM5M2wzb3REc1EzdXZ3clNQQUxqbVRsTU9kX0Rnd3cxMWh1RU52VExVbkhXeTJ2YmRUOU45akp2YmtaSGVUUEVWRklCNmpLVjNkd0NSRTgxM3dRZjAxb2NRcXo0VHRJV19TeEJseTN2Z3FIR0R3TndjbERVQzhDQWFFcFc5Y2lYU2JzOVhxSXcwRWtZU3E0SHVoTUdpQmphYUphUlhoTjdPMlhwN0hNRlFmamFjWVR6; YSC=_lAhFJcIGMw; s_gl=4cbea3d46ab920350acb72593d23a17bcwIAAABUUg==; SID=ugef9GgIMYiaMFE8XWQ1bthebQHf_5zBC-_qWd7gcnorpHWE-SLTAx_KhuM24rdXDczT2A.; __Secure-3PSID=ugef9GgIMYiaMFE8XWQ1bthebQHf_5zBC-_qWd7gcnorpHWE07mvO40IrDna6mCEuOI7FQ.; _ga=GA1.2.1894462781.1585515335; PREF=cvdm=grid&f5=30; wide=0; SIDCC=AJi4QfFD09yYi45BWcL-h_sVWwOseC9CA_mmLWtXaYTbB6G_1tr4Zj2I1GSwpcZiVqk0jIySKyNU',
})